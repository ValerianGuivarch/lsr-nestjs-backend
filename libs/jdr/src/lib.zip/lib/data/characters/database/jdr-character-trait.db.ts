import { Entity, PrimaryColumn, ManyToOne, JoinColumn, CreateDateColumn, UpdateDateColumn } from 'typeorm'
import { DBJdrCharacter } from './jdr-character.db'
import { DBJdrTrait } from '../../traits/database/DBJdrTrait'

@Entity({ name: 'jdr_character_trait' })
export class DBJdrCharacterTrait {
  @CreateDateColumn({ default: () => 'CURRENT_TIMESTAMP' })
  createdDate: Date

  @UpdateDateColumn({ default: () => 'CURRENT_TIMESTAMP' })
  updatedDate: Date

  @PrimaryColumn({ type: 'varchar' })
  jdrSlug: string

  @PrimaryColumn({ type: 'varchar' })
  characterSlug: string

  @ManyToOne(() => DBJdrCharacter, (character) => character.traits, { onDelete: 'CASCADE' })
  @JoinColumn([
    { name: 'jdrSlug', referencedColumnName: 'jdrSlug' },
    { name: 'characterSlug', referencedColumnName: 'slug' }
  ])
  character: DBJdrCharacter

  @PrimaryColumn({ type: 'varchar' })
  traitSlug: string

  @ManyToOne(() => DBJdrTrait, { onDelete: 'CASCADE' })
  @JoinColumn([
    { name: 'jdrSlug', referencedColumnName: 'jdrSlug' },
    { name: 'traitSlug', referencedColumnName: 'slug' }
  ])
  trait: DBJdrTrait
}

export type DBJdrCharacterTraitToCreate = Pick<DBJdrCharacterTrait, 'jdrSlug' | 'characterSlug' | 'traitSlug'>
